package barry.karim;

public class DossierSuivi {
	protected String numero;
		
	public DossierSuivi( String ds) {
		this.numero = ds;
	}
	
	public void setNumero(String ds) {
		this.numero = ds;
	}
	
	public String getNumero() {
		return this.numero;
	}
	

}
