package projetRMI;

public class Animal{
	protected String nom;
	protected String nomMaitre;
	protected Espece espece;
	protected String race;
	protected DossierSuivi dossiersuivi;
	
	public Animal(String nom, String nomMaitre, Espece espece, String race){
		this.nom=nom;
		this.nomMaitre=nomMaitre;
		this.espece=espece;
		this.race=race;
	}
	public Animal(String nom, String nomMaitre, Espece espece, String race, DossierSuivi dossiersuivi) {
		super();
		this.nom = nom;
		this.nomMaitre = nomMaitre;
		this.espece = espece;
		this.race = race;
		this.dossiersuivi = dossiersuivi;
	}
	public Animal(){};
	
	public String getNom(){
		return this.nom;
	}
	public String getNomMaitre(){
		return this.nomMaitre;
	}
	public Espece getEspece(){
		return this.espece;
	}
	public String getRace(){
		return this.race;
	}
	public void setNom(String nom){
		this.nom=nom;
	}
	public void setNomMaitre(String nomMaitre){
		this.nomMaitre=nomMaitre;
	}
	public void setEspece(Espece espece){
		this.espece=espece;
	}
	public void setRace(String race){
		this.race=race;
	}
}
