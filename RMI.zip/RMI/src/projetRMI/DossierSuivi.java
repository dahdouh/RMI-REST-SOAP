package projetRMI;

public class DossierSuivi {
	
	protected String numero;
	
	public DossierSuivi(String num) {
		this.numero = num;
	}
	
	public void setNumero(String num) {
		this.numero = num;
	}
	public String getNumero() {
		return this.numero;
	}

}
